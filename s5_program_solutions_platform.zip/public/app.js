document.getElementById("form").addEventListener("submit",async e=>{
e.preventDefault();
let data=Object.fromEntries(new FormData(e.target));
await fetch('/api/intake',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});
document.getElementById("msg").innerText="Submitted";
});