const express=require('express');
const app=express();
app.use(express.json());
app.use(express.static('public'));
app.post('/api/intake',(req,res)=>{console.log(req.body);res.send({ok:true});});
app.listen(3000,()=>console.log("Running"));